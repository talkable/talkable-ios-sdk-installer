//
//  TestView.m
//  Test
//
//  Created by Kangqijun on 16/9/2.
//  Copyright © 2016年 Kangqijun. All rights reserved.
//

#import "TestView.h"
#import <CoreText/CoreText.h>

@implementation TestView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code

}


@end
